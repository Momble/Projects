//
// Created by MIke Cheng on 5/3/2018.
//
#include "stockAccount.h"
stockAccount::stockAccount() {

}

void stockAccount::menu(vector<string>& portfolio) {
    int stockInput = 0;

    while (stockInput != 6) {
        cout << "Please select an option: \n\t1. Display Current Price for a Stock Symbol\n\t2. Buy Stock\n\t3. Sell Stock\n\t4. Display Current Portfolio\n\t5. Display Transactions History\n\t6.Return to Main Menu\n\nSelection: ";
        cin >> stockInput;
        if (cin.fail()) {
            failsafe(&stockInput);
        }

        switch (stockInput) {
            case 1:
                getPrice();
                break;
            case 2:
                buyStock(portfolio);
                break;
            case 3:
                sellStock(portfolio);
                break;
            case 4:
                displayPortfolio(portfolio);
                break;
            case 5:
                displayHistory();
                break;
            case 6:
                break;

            default:
                if ((stockInput != 1) || (stockInput != 2) || (stockInput != 3)||(stockInput!= 4)||(stockInput != 5)||(stockInput != 6))
                {
                    cout <<"Input a valid value.\n";
                }

                break;
        }
    }
}

void stockAccount::getPrice() {
    string info = getStocks();
    string search;
    string space = "\t";
    vector <string> tokens;

    cout << "Enter a company symbol: ";
    cin >> search;
    if (cin.fail()) {
        failsafe(&search);
    }
    cout << "\n\n";


    ifstream file(info);
    string line;

    while (getline(file, line)) {
        for (int i = 0; i < 3; i++){
            if (i == 2) {
                line = line.substr(line.rfind(space) + 1, string::npos);
                tokens.push_back(line);
            }
            tokens.push_back(line.substr(0, line.find(space)));
            line = line.substr(line.find(space) + 1, string::npos);
        }
    }

    file.close();

    int fail = 1;

        for (int i = 0; i < tokens.size(); i++) {

        if (tokens[i] == search) {
            for (int j = i; j < i + 3; j++) {
                fail = 0;
                cout << tokens[j] << "\t";
            }
            time_t my_time = time(0);
            cout << asctime(localtime(&my_time));
        }
    }

    if (fail == 1){
        cout << "Please enter a valid company symbol." << endl << endl;
    }
    cout << endl << endl;

}

void stockAccount::buyStock(vector<string>& portfolio) {
    string info = getStocks();
    string search;
    int tax;
    double offer;
    string space = "\t";
    vector <string> tokens;
    vector <string> target;
    double price;
    double fulloffer;


    cout << "Enter buy options (Symbol Amount Offer): ";
    cin >> search >> tax >> offer;
    if (cin.fail()) {
        cout << "Symbol: " << endl;
        failsafe(&search);
        cout << "Amount: " << endl;
        failsafe(&tax);
        cout << "Offer: " << endl;
        failsafe(&offer);

    }
    cout << "\n\n";

    ifstream file(info);
    string line;

    while (getline(file, line)) {
        for (int i = 0; i < 3; i++) {
            if (i == 2) {
                line = line.substr(line.rfind(space) + 1, string::npos);
                tokens.push_back(line);
            }
            tokens.push_back(line.substr(0, line.find(space)));
            line = line.substr(line.find(space) + 1, string::npos);
        }
    }

    file.close();

    int fail = 1;

    for (int i = 0; i < tokens.size(); i++) {

        if (tokens[i] == search) {
            for (int j = i; j < (i + 3); j++) {
                fail = 0;
                target.push_back(tokens[j]);
            }
        }
    }

    if (fail == 1) {
        cout << "Please enter a valid company symbol." << endl << endl;
        return;
    }

    fulloffer = offer * tax;
    price = stod(target[2]) * tax;



    if ((price <= fulloffer) & (fulloffer <= getBalance())) {

        int added = 0;

        for (int k = 0; k < portfolio.size(); k++) {
            if (portfolio[k] == search) {
                portfolio[k + 1] = to_string(stod(portfolio[k + 1]) + tax);
                added = 1;
            }
        }

        if (added == 0) {
            portfolio.push_back(target[0]);
            portfolio.push_back(to_string(tax));
        }
        setBalance(getBalance() - price);

        time_t my_time = time(0);
        string transaction = "Buy\t" + search + "\t" + to_string(tax) + "\t" + target[2] + "\t" + asctime(localtime(&my_time));
        ofstream myfile;
        myfile.open("stock_transaction_history.txt", ios_base::app);
        myfile << transaction;
        myfile.close();
        cout << endl << endl;
    }

    else cout << "Cannot process transaction" << endl;

}

void stockAccount::sellStock(vector<string>& portfolio) {
    string info = getStocks();
    string search;
    int tax;
    double offer;
    string space = "\t";
    vector <string> tokens;
    vector <string> target;
    double price;
    cout << "Enter sell options (Symbol Amount Offer): ";
    cin >> search >> tax >> offer;
    if (cin.fail()) {
        cout << "Symbol: " << endl;
        failsafe(&search);
        cout << "Amount: " << endl;
        failsafe(&tax);
        cout << "Offer: " << endl;
        failsafe(&offer);
    }
    cout << "\n\n";

    ifstream file(info);
    string line;

    while (getline(file, line)) {
        for (int i = 0; i < 3; i++) {
            if (i == 2) {
                line = line.substr(line.rfind(space) + 1, string::npos);
                tokens.push_back(line);
            }
            tokens.push_back(line.substr(0, line.find(space)));
            line = line.substr(line.find(space) + 1, string::npos);
        }
    }

    file.close();

    int fail = 1;

    for (int i = 0; i < tokens.size(); i++) {
        if (tokens[i] == search) {
            for (int j = i; j < (i + 3); j++) {
                fail = 0;
                target.push_back(tokens[j]);
            }
        }
    }

    if (fail == 1) {
        cout << "Please enter a valid company symbol." << endl << endl;
        return;
    }

    price = stod(target[2]);

    if (price >= offer) {

        int sold = 0;

        for (int k = 0; k < portfolio.size(); k++) {
            if (portfolio[k] == search) {
                if (stod(portfolio[k + 1]) >= tax) {
                    portfolio[k + 1] = to_string(stoi(portfolio[k + 1]) - tax);
                    sold = 1;
                    if (stod(portfolio[k + 1]) == 0) {
                        portfolio.erase(portfolio.begin() + k + 1);
                        portfolio.erase(portfolio.begin() + k);
                    }
                }
            }
        }

        if (sold == 0) {
            cout << "You dont have that stock to sell!";
        }
        setBalance(getBalance() + (tax*price));

        time_t my_time = time(0);
        string transaction = "Sell\t" + search + "\t" + to_string(tax) + "\t" + target[2] + "\t" + asctime(localtime(&my_time));
        ofstream myfile;
        myfile.open("stock_transaction_history.txt", ios_base::app);
        myfile << transaction;
        myfile.close();
        cout << endl << endl;
    }

    else cout << "Cannot process transaction" << endl;


}

void stockAccount::displayPortfolio(vector<string>& portfolio) {
    string info = getStocks();
    string space = "\t";
    vector <string> tokens;



    cout << "Cash Balance: $" << getBalance() << endl << endl;
    cout << "Symbol\tCompany\t\t\tNumber\tPrice\tTotal" << endl;

    ifstream file(info);
    string line;

    while (getline(file, line)) {
        for (int i = 0; i < 3; i++) {
            if (i == 2) {
                line = line.substr(line.rfind(space) + 1, string::npos);
                tokens.push_back(line);
            }
            tokens.push_back(line.substr(0, line.find(space)));
            line = line.substr(line.find(space) + 1, string::npos);
        }
    }

    file.close();

    for (int i = 0; i < portfolio.size(); i = i+2) {
        for (int j = 0; j < tokens.size(); j++) {
            if (portfolio[i] == tokens[j]) {
                cout << tokens[j] << "\t" << tokens[j + 1] << "\t" << portfolio[i + 1] << "\t" << tokens[j + 2] << "\t" << (to_string(stod(portfolio[i + 1]) * stod(tokens[j + 2]))) << endl;
            }
        }
    }

    cout << endl;

}

void stockAccount::displayHistory() {



    cout << "Action\tSymbol\tShares\tPrice\tTime" << endl;
    ifstream file("stock_transaction_history.txt");
    string line;
    while (getline(file, line))
        cout << line << endl;
    file.close();

    cout << endl;
}