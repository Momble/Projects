//
// Created by MIke Cheng on 2/28/2018.
//

#ifndef BANK_HEADER_FILE_H
#define BANK_HEADER_FILE_H

#endif //BANK_HEADER_FILE_H
#include <iostream>
#include <vector>
#include <string>
#include <array>
#include <cstdlib>
#include <ctime>
#include <iomanip>
#include <algorithm>
using namespace std;
struct Account
{
    int accountNumber;
    string lastName;
    string firstName;
    bool active = true;
    double accountBalance;
};
void menu(int*num);
void sortAccounts(vector<Account>& bankaccounts)
{
    bankaccounts.push_back(Account());
    int temp = bankaccounts.size() -1;
    for(int i = 0; i < bankaccounts.size(); i ++)
    {   for(int j = 0; j< bankaccounts.size(); j++)
        {
            if(bankaccounts[i].accountNumber < bankaccounts[j].accountNumber)
            {
                bankaccounts[temp]=bankaccounts[j];
                bankaccounts[j]=bankaccounts[i];
                bankaccounts[i]=bankaccounts[temp];
            }
        }
    }
    bankaccounts.erase(bankaccounts.end()-1);
}
void makeAccount(vector<Account>& bankaccounts)
{
    Account temp;
    srand(time(NULL));
    temp.accountNumber = (rand()%9+1)*1000+(rand()%9+1)*100+(rand()%9+1)*10+(rand()%9+1);
    for(int i = 0; i < bankaccounts.size();i++)
    {
        if (temp.accountNumber == bankaccounts[i].accountNumber)
        {
            temp.accountNumber = (rand()%9+1)*1000+(rand()%9+1)*100+(rand()%9+1)*10+(rand()%9+1);
        }
    }
    cout << "This bank account is index number: " << temp.accountNumber << endl;

    cout << "Last Name: " << endl;

    cin >> temp.lastName;

    cout << "First Name: " << endl;
    cin >> temp.firstName;

    cout << "Starting Balance :" << endl;
    cin >> temp.accountBalance;

    bankaccounts.push_back(temp);
    sortAccounts(bankaccounts);
}
void printAccount(vector<Account>& bankaccounts)
{
    int i =0;
    int accountNum;
    cout << "What account would you like to view? " << endl;
    cin >> accountNum;
    while( i <= bankaccounts.size()-1)
    {
        if ((bankaccounts[i].accountNumber == accountNum) && (bankaccounts[i].active == true))
        {
            cout << "Account Number: " << accountNum;
            cout << setw(4)<< " ";
            cout << "Balance: " << bankaccounts[i].accountBalance;
            cout << endl;
            cout << "Last Name: " << bankaccounts[i].lastName;
            cout << setw(4)<< " ";
            cout << "First Name: " << bankaccounts[i].firstName << endl;
        }
        else {
            cout << "Invalid Account Number or is deactive." << endl;
        }
        i++;

    }
}
void transfer(vector<Account>& bankaccounts)
{
    double tempF;
    double tempT;
    int accountFrom, accountTo;
    double transAmount;


    cout << "From which account would you like to make a transfer from? Please enter account number: " << endl;
    cin >> accountFrom;
    cout << endl << "From which account would you like to make a transfer to? Please enter account number: " << endl;
    cin >> accountTo;
    cout << "How much would you like to transfer? :" << endl;
    cin >> transAmount;
    for(int j = 0; j <= bankaccounts.size()-1; j++)
    {
        if (accountFrom == bankaccounts[j].accountNumber && bankaccounts[j].active == true)
        {
            tempF = bankaccounts[j].accountBalance;
            bankaccounts[j].accountBalance = tempF - transAmount;
            cout << "The new balance for account " << accountFrom << " is " << bankaccounts[j].accountBalance << ". " << endl;
        }
        else
        {
            cout<< "Account is deactive."<< endl;
        }
    }
    for (int i = 0; i <= bankaccounts.size()-1; i++)
    {
        if (accountTo == bankaccounts[i].accountNumber && bankaccounts[i].active == true) {
            tempT = bankaccounts[i].accountBalance;
            bankaccounts[i].accountBalance = tempT + transAmount;
            cout << "The new balance for account " << accountTo << " is " << bankaccounts[i].accountBalance << ". " << endl;
        }
        else
        {
            cout << "Account is deactive"<<endl;
        }
    }
}
void PrintAllAccount(vector<Account>& bankaccounts)
{

    for (int i= 0;i<=bankaccounts.size()-1; i++)
    {
        if(bankaccounts[i].active == true)
        {
            cout << "Account Number: " << bankaccounts[i].accountNumber;
            cout << setw(4)<<" ";
            cout << "Balance: " << bankaccounts[i].accountBalance;
            cout << endl;
            cout << "Last Name: " << bankaccounts[i].lastName;
            cout << setw(4)<<" ";
            cout << "First Name: " << bankaccounts[i].firstName << endl << endl;
        }
        else
        {
            cout << "";
        }

    }
}
void depositAccount(vector<Account>& bankaccounts)
{
    int deposAccount, deposAmount;

    cout << "From which account would you like to make a deposit to? Please enter account number: " << endl;
    cin >> deposAccount;
    cout << "How much would you like to deposit? :" << endl;
    cin >> deposAmount;

    vector<Account>::iterator i;

    for (i=bankaccounts.begin();i<=bankaccounts.end(); i++)
    {
        if((*i).active == true)
        {
            if ((*i).accountNumber == deposAccount) {
                (*i).accountBalance += deposAmount;
                cout << "The new balance for account " << deposAccount << "is " << (*i).accountBalance;
            }
            else{
                cout << "Invalid Account Number." << endl;
            }
        }
        else
        {
            cout << "Account is not active.";
        }
    }
}
void ActiveDeactive(vector<Account>& bankaccounts)
{
    int acctNum;
    int num;

    cout << "Would you to to activate or deactivate? 1 for activate and 0 for deactivate. " << endl;
    cin >> num;
    cout << "Enter account number: " << endl;
    cin >> acctNum;

    int indextodeactive=0;
    int active = 1;
    if(num == 0)
    {
        for (int i =0 ; i <= bankaccounts.size(); i++)
        {
            if (bankaccounts[i].accountNumber == acctNum)
            {

                indextodeactive=i;
                break;

            }
        }
        bankaccounts[indextodeactive].active = false;
    }
    else
    {
        for (int i =0 ; i <= bankaccounts.size(); i++)
        {
            if (bankaccounts[i].accountNumber == acctNum)
            {

                active=i;
                break;

            }
        }
        bankaccounts[indextodeactive].active = true;
    }
}
void withdrawAccount(vector<Account>& bankaccounts)
{
    int withdrawAccount;
    double withdrawAmount;

    cout << "From which account would you like to make a withdraw from? Please enter account number: " << endl;
    cin >> withdrawAccount;
    cout << "How much would you like to withdraw? :" << endl;
    cin >> withdrawAmount;

    vector<Account>::iterator i;

    for (i=bankaccounts.begin();i<=bankaccounts.end(); i++) {
        if((*i).active == true)
        {
            if ((*i).accountNumber == withdrawAccount) {
                if (withdrawAmount <= ((*i).accountBalance)) {
                    (*i).accountBalance -= withdrawAmount;
                    cout << "The new balance for account " << withdrawAccount << "is " << (*i).accountBalance;
                }
                else{
                    cout << "Insufficient Funds"<< endl;
                }
            }
            else {
                cout << "Invalid Account Number." << endl;
            }
        }
        else
        {
            cout<<"Account is not active.";
        }
    }
}

void deleteAccount(vector<Account>& bankaccounts)
{
    int deleteacct;

    cout << "What account would you like to delete?" << endl;
    cin >> deleteacct;

    vector<Account>:: iterator i;
    for (i=bankaccounts.begin(); i <= bankaccounts.end(); i++){
        if ((*i).accountNumber == deleteacct && (*i).active == true){
            bankaccounts.erase(i);
            cout << "Account " << deleteacct << " was successfully deleted" << endl;
        }
        else {
            cout << "Invalid Account Number or deactive." << endl;
        }
    }
}
