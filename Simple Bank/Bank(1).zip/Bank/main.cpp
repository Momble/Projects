
#include <iostream>
#include "header_file.h"
using namespace std;

int main()
{
    vector <Account> bankaccounts;
    int input = 0;
    while (input <= 9)
    {
        menu(&input);
        switch (input)
        {
            case 1:
                makeAccount(bankaccounts);
                break;
            case 2:
                depositAccount(bankaccounts);
                break;
            case 3:
                withdrawAccount(bankaccounts);
                break;
            case 4:
                transfer(bankaccounts);
                break;
            case 5:
                printAccount(bankaccounts);
                break;
            case 6:
                ActiveDeactive(bankaccounts);
                break;
            case 7:
                deleteAccount;
                break;
            case 8:
                PrintAllAccount(bankaccounts);
                break;
            case 9: return 0;

            default : cout << "Invalid choice please enter a number between 0 and 9 from the menu above" << endl;
        }
    }
    return 0;
}