//
// Created by MIke Cheng on 5/1/2018.
//

#ifndef UNTITLED1_ACCOUNT_H
#define UNTITLED1_ACCOUNT_H
#include <iostream>
#include <time.h>
#include <string>
#include <fstream>
#include <vector>
#include <chrono>
#include <iomanip>
using namespace std;

template <typename T>
void failsafe(T *input) {
    while (cin.fail()) {
        cin.clear();
        cin.ignore();
        cout << "Invalid input, please enter a valid entry: ";
        cin >> *input;
    }
}

class Account {

private:
    static double cashBalance;

public:
    Account();
    string getStocks();
    void setBalance(double);
    double getBalance();
};
#endif //UNTITLED1_ACCOUNT_H
