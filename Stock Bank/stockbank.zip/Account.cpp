//
// Created by MIke Cheng on 5/1/2018.
//

#include "Account.h"
#include <time.h>
#include <cstdlib>
#include <fstream>
#include <cmath>
#include <string>
#include <iostream>
double Account::cashBalance = 10000;

Account::Account() {

}

double Account::getBalance() {
    return cashBalance;
}

string Account::getStocks() {
    srand(time(NULL));
    int num = rand() % 4 + 1;
    string name = "stock" + to_string(num) + ".txt";
    return name;
}

void Account::setBalance(double newValue) {
    cashBalance = newValue;
}