//
// Created by MIke Cheng on 5/2/2018.
//

#include <iomanip>
#include "BankAccount.h"
#include <time.h>
#include <cstdlib>
#include <fstream>
#include <cmath>
#include <string>
#include <iostream>
#include "bankAccount.h"



bankAccount::bankAccount() {

}

void bankAccount:: menu(vector<string>& portfolio) {
    int bankInput = 0;

    while (bankInput != 5) {
        cout << "Please select an option: \n\t1. View Account Balance\n\t2. Deposit Money\n\t3. Withdraw Money\n\t4. Display Transaction History\n\t5. Return to Main Menu\n\n Selecton: ";
        cin >> bankInput;
        if (cin.fail()) {
            failsafe(&bankInput);
        }

        switch (bankInput) {
            case 1:
                balance(portfolio);
                break;
            case 2:
                deposit(portfolio);
                break;
            case 3:
                withdraw(portfolio);
                break;
            case 4:
                displayHistory();
                break;
            case 5:
                break;

            default:
                if ((bankInput != 1) || (bankInput != 2) || (bankInput != 3)||(bankInput!= 4)||(bankInput != 5))
                {
                    cout <<"Input a valid value..\n";
                }

                break;
        }
    }
}

void bankAccount::balance(vector<string>& portfolio) {
    string info = getStocks();
    string space = "\t";
    vector <string> tokens;



    cout << "Cash Balance: $" << getBalance() << endl << endl;
    cout << "Symbol\tCompany\t\t\tNumber\tPrice\tTotal" << endl;

    ifstream file(info);
    string line;

    while (getline(file, line)) {
        for (int i = 0; i < 3; i++) {
            if (i == 2) {
                line = line.substr(line.rfind(space) + 1, string::npos);
                tokens.push_back(line);
            }
            tokens.push_back(line.substr(0, line.find(space)));
            line = line.substr(line.find(space) + 1, string::npos);
        }
    }

    file.close();

    for (int i = 0; i < portfolio.size(); i = i + 2) {
        for (int j = 0; j < tokens.size(); j++) {
            if (portfolio[i] == tokens[j]) {
                cout << tokens[j] << "\t" << tokens[j + 1] << "\t" << portfolio[i + 1] << "\t" << tokens[j + 2] << "\t" << (to_string(stod(portfolio[i + 1]) * stod(tokens[j + 2]))) << endl;
            }
        }
    }

    cout << endl;

}

void bankAccount::deposit(vector<string>& portfolio) {
    double deposit;
    double currentBal = getBalance();

    cout << "Enter positive deposit amount: ";
    cin >> deposit;
    if (cin.fail()) {
        failsafe(&deposit);
    }

    if (deposit < 0) {
        cout << "Enter a positive value." << endl << endl;
        return;
    }

    setBalance(deposit + currentBal);
    cout << "Deposit $" << deposit << " into Bank Account." << endl;

    balance(portfolio);

    time_t my_time = time(0);
    string transaction = "Deposit\t\t" + to_string(deposit) + "\t" + to_string(getBalance()) + "\t" + asctime(localtime(&my_time));
    ofstream myfile;
    myfile.open("bank_transaction_history.txt", ios_base::app);
    myfile << transaction;
    myfile.close();
    cout << endl << endl;
}

void bankAccount::withdraw(vector<string>& portfolio) {
    double withdraw = 0;
    double currentBal = getBalance();

    cout << "Enter positive amount to withdraw: ";
    cin >> withdraw;
    if (cin.fail()) {
        failsafe(&withdraw);
    }

    if (withdraw < 0) {
        cout << "Enter a positive value." << endl << endl;
        return;
    }

    if (withdraw > getBalance()) {
        cout << "You don't have that much to withdraw!" << endl << endl;
        return;
    }

    setBalance(currentBal - withdraw);
    cout << "Withdraw $" << withdraw << " from Bank Account." << endl;

    balance(portfolio);

    time_t my_time = time(0);
    string transaction = "Withdrawal\t" + to_string(withdraw) + "\t" + to_string(getBalance()) + "\t" + asctime(localtime(&my_time));
    ofstream myfile;
    myfile.open("bank_transaction_history.txt", ios_base::app);
    myfile << transaction;
    myfile.close();
    cout << endl << endl;
}

void bankAccount::displayHistory() {

    cout << "Action\t\tAmount\t\tCash Balance\tTime" << endl;
    ifstream file("bank_transaction_history.txt");
    string line;
    while (getline(file, line))
        cout << line << endl;
    file.close();

    cout << endl;
}

