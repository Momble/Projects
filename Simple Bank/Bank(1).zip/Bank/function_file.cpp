//
// Created by MIke Cheng on 3/27/2018.
//
#include <iostream>
using namespace std;
void menu(int *num)
{
    int select = 0;
    cout << "Welcome! Select options below:" << endl;
    cout << "\t1. Make new account.";
    cout << "\n\t2. Deposit to an account.";
    cout << "\n\t3. Withdraw from an account.";
    cout << "\n\t4. Transfer money."
         << "\n\t5. Print account." << "\n\t6. Activate/Deactivate an account."<<
         "\n\t7. Delete an account." << "\n\t8. Display all accounts."
         << "\n\t9. Quit." << endl;
    cout << "Selection:\t";
    cin >> select;
    *num = select;
}