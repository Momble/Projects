//
// Created by MIke Cheng on 5/1/2018.
//

#ifndef UNTITLED1_BANKACCOUNT_H
#define UNTITLED1_BANKACCOUNT_H
#include "Account.h"

class bankAccount : public Account {

public:
    bankAccount();
    void menu(vector<string>&);
    void balance(vector<string>&);
    void deposit(vector<string>&);
    void withdraw(vector<string>&);
    void displayHistory();
};
#endif //UNTITLED1_BANKACCOUNT_H
