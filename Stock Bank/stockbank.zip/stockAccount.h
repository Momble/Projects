//
// Created by MIke Cheng on 5/3/2018.
//

#ifndef UNTITLED1_STOCKACCOUNT_H
#define UNTITLED1_STOCKACCOUNT_H
#include <iomanip>
#include "Account.h"
#include <time.h>
#include <cstdlib>
#include <fstream>
#include <cmath>
#include <string>
using namespace std;

class stockAccount : public Account {

public:

    stockAccount();
    void menu(vector<string>&);
    void getPrice();
    void buyStock(vector<string>&);
    void sellStock(vector<string>&);
    void displayPortfolio(vector<string>&);
    void displayHistory();
};
#endif //UNTITLED1_STOCKACCOUNT_H
